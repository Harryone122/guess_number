document.getElementById('startGameButton').addEventListener('click', function() {
    fetch('/start')
        .then(response => response.json())
        .then(data => {
            document.getElementById('rangeInfo').innerHTML = `此次遊戲範圍為${data.range}`;
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
        });
    this.style.opacity = '0';
    setTimeout(() => {
        this.style.display = 'none';
        document.getElementById('gameInfo').style.display = 'block';
        document.getElementById('userGuess').style.display = 'inline';
        document.getElementById('attemptInfo').style.display = 'inline';
    }, 600);
});

document.getElementById('userGuess').addEventListener('change', function() {
    const guess = this.value;
    fetch('/guess', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ guess }),
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('userGuess').value = '';
        document.getElementById('rangeInfo').innerHTML = data.message; 
        if ('attempts' in data) {
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
        } else {
            document.getElementById('attemptInfo').innerHTML = ''; 
        }
    
        if (data.correct || typeof data.attempts === 'undefined' || data.attempts === 0) {
            document.getElementById('restartGameButton').style.display = 'block';
        }
    });
    
});

document.getElementById('restartGameButton').addEventListener('click', function() {
    document.getElementById('startGameButton').click(); 
    this.style.display = 'none'; 
});

document.getElementById('restartGameButton').addEventListener('click', function() {
    fetch('/start') 
        .then(response => response.json())
        .then(data => {
            document.getElementById('rangeInfo').innerHTML = `此次遊戲範圍為${data.range}`;
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
            document.getElementById('startGameButton').style.opacity = '1';
            document.getElementById('startGameButton').style.display = 'block'; 
            document.getElementById('gameInfo').style.display = 'none';
            document.getElementById('restartGameButton').style.display = 'none'; 
        });
});
