document.getElementById('startGameButton').addEventListener('click', function() {
    fetch('/start')
        .then(response => response.json())
        .then(data => {
            document.getElementById('rangeInfo').innerHTML = `此次遊戲範圍為${data.range}`;
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
        });
    this.style.opacity = '0';
    setTimeout(() => {
        this.style.display = 'none';
        document.getElementById('gameInfo').style.display = 'block';
        document.getElementById('userGuess').style.display = 'inline';
        document.getElementById('attemptInfo').style.display = 'inline';
    }, 600);
});

document.getElementById('userGuess').addEventListener('change', function() {
    const guess = this.value;
    fetch('/guess', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ guess }),
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('userGuess').value = ''; // 每次提交猜測後清空輸入欄
        if (data.correct) {
            document.getElementById('rangeInfo').innerHTML = data.message;
            document.getElementById('restartGameButton').style.display = 'block';
        } else {
            document.getElementById('rangeInfo').innerHTML = `此次遊戲範圍為${data.message}`;
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
            if (data.attempts === 0) {
                document.getElementById('gameInfo').innerHTML = data.message;
                document.getElementById('restartGameButton').style.display = 'block';
            }
        }
    });
});

document.getElementById('restartGameButton').addEventListener('click', function() {
    document.getElementById('startGameButton').click(); // 模擬點擊開始遊戲按鈕
    this.style.display = 'none'; // 隱藏重新開始遊戲按鈕
});
