document.getElementById('startGameButton').addEventListener('click', function() {
    fetch('/start')
        .then(response => response.json())
        .then(data => {
            document.getElementById('rangeInfo').innerHTML = `此次遊戲範圍為${data.range}`;
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
        });
    this.style.opacity = '0';
    setTimeout(() => {
        this.style.display = 'none';
        document.getElementById('gameInfo').style.display = 'block';
        document.getElementById('userGuess').style.display = 'inline';
        document.getElementById('attemptInfo').style.display = 'inline';
    }, 600);
});

document.getElementById('userGuess').addEventListener('change', function() {
    const guess = this.value;
    fetch('/guess', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ guess }),
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('userGuess').value = '';
        document.getElementById('rangeInfo').innerHTML = data.message; // 統一處理遊戲信息更新
    
        if ('attempts' in data) {
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
        } else {
            document.getElementById('attemptInfo').innerHTML = ''; // 不顯示剩餘次數
        }
    
        // 不論遊戲結果如何，只要是遊戲結束，就顯示“再來一局”按鈕
        if (data.correct || typeof data.attempts === 'undefined' || data.attempts === 0) {
            document.getElementById('restartGameButton').style.display = 'block';
        }
    });
    
});

document.getElementById('restartGameButton').addEventListener('click', function() {
    document.getElementById('startGameButton').click(); 
    this.style.display = 'none'; 
});

document.getElementById('restartGameButton').addEventListener('click', function() {
    fetch('/start') // 重新初始化遊戲變數
        .then(response => response.json())
        .then(data => {
            document.getElementById('rangeInfo').innerHTML = `此次遊戲範圍為${data.range}`;
            document.getElementById('attemptInfo').innerHTML = `剩餘次數: ${data.attempts}`;
            document.getElementById('startGameButton').style.opacity = '1';
            document.getElementById('startGameButton').style.display = 'block'; // 重新顯示開始遊戲按鈕
            document.getElementById('gameInfo').style.display = 'none'; // 隱藏遊戲信息
            document.getElementById('restartGameButton').style.display = 'none'; // 隱藏“再來一局”按鈕
        });
});
